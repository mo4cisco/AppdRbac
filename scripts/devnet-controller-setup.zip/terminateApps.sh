#!/bin/bash



echo "CloudWorkshop|INFO| - Stopping Local Application"
echo " "

#/opt/appdynamics/workshopuser/pre-mod-docker/stop.sh

echo " "
echo "CloudWorkshop|INFO| - Finished Stopping Local Application"


